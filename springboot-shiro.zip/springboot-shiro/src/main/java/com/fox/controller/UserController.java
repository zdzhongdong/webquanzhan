package com.fox.controller;



import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class UserController {
	
	@RequestMapping("/thymeleaf")
	public String testThymeleaf(Model model) {
		model.addAttribute("name", "hemaliale");
		return "test";
	}
	@RequestMapping("/add")
	public String add() {
		return "/user/adduser";
	}
	@RequestMapping("/update")
	public String update() {
		return "/user/updateuser";
	}
	@RequestMapping("/tologin")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/noAuth")
	public String noAuth() {
		return "noAuth";
	}
@RequestMapping("/login")
	public String login(String name,String pwd,Model model) {
	/**
	 * 使用shiro编写认证操作
	 */
	//获取subject
	Subject subject = SecurityUtils.getSubject();
	//封装用户数据
	UsernamePasswordToken token = new UsernamePasswordToken(name, pwd);
	//执行登录方法
	try {
		subject.login(token);
		//登录成功
		//跳转到test页面
		return "redirect:/thymeleaf";
	} catch (UnknownAccountException e) {
		
		//e.printStackTrace();
		//登录失败:用户名不存在
		model.addAttribute("msg", "用户名不存在");
		return "login";
	}catch (IncorrectCredentialsException e) {
		
		//e.printStackTrace();
		//登录失败:密码错误
		model.addAttribute("msg", "密码错误!!!!");
		return "login";
	}
	
}

}
