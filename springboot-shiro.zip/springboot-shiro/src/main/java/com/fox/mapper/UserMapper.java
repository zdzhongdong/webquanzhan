package com.fox.mapper;

import com.fox.domain.UserEntity;

public interface UserMapper {

	public UserEntity findUser(String userName);
	
}
