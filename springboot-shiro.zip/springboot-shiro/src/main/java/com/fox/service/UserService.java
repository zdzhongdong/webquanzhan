package com.fox.service;

import com.fox.domain.UserEntity;

public interface UserService {

	public UserEntity findUser(String username);
}
