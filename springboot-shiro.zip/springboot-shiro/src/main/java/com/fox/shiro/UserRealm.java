package com.fox.shiro;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import com.fox.domain.UserEntity;
import com.fox.service.UserService;

/**自定义Realm
 * @author C3410596
 *
 */
public class UserRealm extends AuthorizingRealm {
	@Autowired
	private UserService us;

	/**
	 *执行授权逻辑
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// 给资源进行授权
		System.out.println("执行授权逻辑");
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
//		info.addStringPermission("user:add");
//		info.addStringPermission("user:update");
		Subject subject=SecurityUtils.getSubject();
		UserEntity userent = (UserEntity)subject.getPrincipal();
		System.out.println(userent.getPerms());
		info.addStringPermission(userent.getPerms());
		return info;
	}

	/**
	 *执行认证逻辑
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		System.out.println("执行认证逻辑");
		// 编写shiro认证逻辑，判断用户名和密码
		//1.判断用户名
		UsernamePasswordToken tok = (UsernamePasswordToken)token;
		UserEntity user = us.findUser(tok.getUsername());
//		System.out.println(user.getUserName()+"-------用户信息------"+user.getPwd());
		if(null==user) {
			return null;//当返回null时，shiro底层会抛出UnknownAccountException
		}
		//验证密码	
		return new SimpleAuthenticationInfo(user,user.getPwd(),"");
	}

}
